﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IAdd
{
    void Add(List<string> input);
}