﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IResidents
{
    string Id { get; }
    string Name { get; }
}