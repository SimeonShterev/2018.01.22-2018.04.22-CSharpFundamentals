﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        Person someone = new Person();
        someone.Age = 20;
        someone.Name = "Pesho";
        Person someoneElse = new Person();
        someoneElse.Name = "Gosho";
        someoneElse.Age = 18;
        Person someoneElsee = new Person();
        someoneElsee.Name = "Stamat";
        someoneElsee.Age = 43;
        //Console.WriteLine($"Name {someone.Name} Age {someone.Age}");
        //Console.WriteLine($"Name {someoneElse.Name} Age {someoneElse.Age}");
    }
}
