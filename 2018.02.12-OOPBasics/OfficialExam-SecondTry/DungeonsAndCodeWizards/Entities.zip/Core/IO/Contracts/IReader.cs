﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Core.IO.Contracts
{
    public interface IReader
    {
		string ReadLine();
    }
}
