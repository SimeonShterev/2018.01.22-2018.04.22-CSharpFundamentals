﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Core.IO.Contracts
{
    public interface IWriter
    {
		void WriteLine(string text);
    }
}
