﻿using System;
using System.Collections.Generic;
using System.Text;

public static class Consts
{
	public const string OutOfFuel = "Out of fuel";
	public const string BlownTyre = "Blown Tyre";
	public const string Crashed = "Crashed";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
	//public const string  = "";
}