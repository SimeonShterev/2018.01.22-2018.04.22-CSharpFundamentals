﻿using System;
using System.Collections.Generic;
using System.Text;

public class ConsoleWriter
{
	public void WriteLine(string text)
	{
		Console.WriteLine(text);
	}
}