﻿using DungeonsAndCodeWizards.Abstracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Classes.Items
{
	public class HealthPotion : Item
	{
		public HealthPotion() 
			: base(5)
		{
		}
	}
}
