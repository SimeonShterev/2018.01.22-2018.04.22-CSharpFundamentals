﻿using DungeonsAndCodeWizards.Abstracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Classes.Items
{
	public class ArmorRepairKit : Item
	{
		public ArmorRepairKit() 
			: base(10)
		{
		}
	}
}
