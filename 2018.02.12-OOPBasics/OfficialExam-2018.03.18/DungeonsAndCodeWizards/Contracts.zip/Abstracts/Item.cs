﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Abstracts
{
    public abstract class Item
    {
		protected Item(int weight)
		{
			this.Weight = weight;
		}

		public int Weight { get; }

		public void AffectCharacter(Character character)
		{
			bool isAlive = character.IsAlive;
			throw new InvalidOperationException(ErrorMessages.Alive);
		}
	}
}
