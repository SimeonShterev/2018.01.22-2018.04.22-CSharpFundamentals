﻿using DungeonsAndCodeWizards.Classes.Bags;
using DungeonsAndCodeWizards.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Abstracts
{
	public abstract class Character
	{
		protected Character(string name, double baseHealth, double baseArmor, double abilityPoints, Bag bag, Faction faction)
		{
			this.Name = name;
			this.BaseHealth = baseHealth;
			this.Health = baseHealth;
			this.BaseArmor = baseArmor;
			this.Armor = baseArmor;
			this.AbilityPoints = abilityPoints;
			this.Bag = bag;
			this.Faction = faction;
		}
			

		public string Name { get; private set; }

		public double Health { get; set; }

		public double BaseHealth { get; set; }

		public double Armor { get; set; }

		public double BaseArmor { get; set; }

		public double AbilityPoints { get; set; }

		public Bag Bag { get; set; }

		public bool IsAlive { get; set; }

		public double RestHealMultiplier { get; protected set; }

		public Faction Faction { get; }

		public void TakeDamage(double hitPoints)
		{

		}

		public void Rest()
		{

		}

		public void UseItem(Item item)
		{

		}

		public void UseItemOn(Item item, Character character)
		{

		}

		public void GiveCharacterItem(Item item, Character character)
		{

		}

		public void ReceiveItem(Item item)
		{

		}
	}
}
