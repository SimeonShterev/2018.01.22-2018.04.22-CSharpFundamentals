﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Abstracts
{
    public abstract class Bag
    {
		protected Bag(int capacity)
		{
			this.Capacity = capacity;
		}

		public int Capacity { get; }

		public int Load { get; protected set; } // private set

		public IReadOnlyCollection<Item> Items { get; }

		public void AddItem(Item item)
		{

		}

		public Item GetItem(string name)
		{
			throw new NotImplementedException();
		}

	}
}
