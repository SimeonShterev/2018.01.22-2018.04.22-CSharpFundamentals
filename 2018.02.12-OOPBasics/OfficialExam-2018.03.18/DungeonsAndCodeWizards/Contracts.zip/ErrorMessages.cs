﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards
{
    public static class ErrorMessages
    {
		public static string Alive = "Must be alive to perform this action!";


    }
}
