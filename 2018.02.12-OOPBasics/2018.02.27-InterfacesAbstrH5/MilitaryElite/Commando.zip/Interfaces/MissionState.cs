﻿public enum MissionState
{
    inProgress, Finished
}