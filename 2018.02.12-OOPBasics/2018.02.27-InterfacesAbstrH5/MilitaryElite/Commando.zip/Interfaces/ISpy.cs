﻿using System;
using System.Collections.Generic;
using System.Text;

    public interface ISpy : ISolder
    {
        int CodeNumber { get; }
    }