﻿using System;

class Program
{
    static void Main(string[] args)
    {
        string command;
        while ((command=Console.ReadLine())!="End")
        {
            string[] input = command.Split();
            string name = input[0];
            string country = input[1];
            int age = int.Parse(input[2]);
            Citizen citizen = new Citizen(name, country, age);
            IPerson citizenAsPerson = (IPerson)citizen;
            IResident citizenAsResident = (IResident)citizen;
            Console.WriteLine(citizenAsPerson.GetName());
            Console.WriteLine(citizenAsResident.GetName());
        }
    }
} 