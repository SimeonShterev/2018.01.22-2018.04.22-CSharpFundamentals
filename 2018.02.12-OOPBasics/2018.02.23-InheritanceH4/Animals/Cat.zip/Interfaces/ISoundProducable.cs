﻿using System.Collections.Generic;

public interface ISoundProducable
{
    string ProduceSound();
}