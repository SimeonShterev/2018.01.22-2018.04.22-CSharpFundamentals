﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IMonuments
{
	string Name { get; }
	int Affinity { get; }
}