﻿using System;
using System.Collections.Generic;
using System.Text;

public enum Signals
{
	Green,
	Yellow,
	Red
}