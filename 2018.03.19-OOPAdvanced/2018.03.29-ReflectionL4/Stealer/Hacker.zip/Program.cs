﻿using System;
using System.Collections.Generic;
using System.Reflection;

[SoftUni("Simo")]
class Program
{
	[SoftUni("Shterev")]
	static void Main(string[] args)
	{
	}
}
