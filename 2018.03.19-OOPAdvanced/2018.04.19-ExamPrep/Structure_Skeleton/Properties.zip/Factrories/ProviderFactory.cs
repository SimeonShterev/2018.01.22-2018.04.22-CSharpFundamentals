﻿using System;
using System.Collections.Generic;

public class ProviderFactory : IProviderFactory
{
    public IProvider GenerateProvider(IList<string> args)
    {
		string typeName = args[1] + args[0];
		Type providerType = Type.GetType(typeName);

        int id = int.Parse(args[2]);
        double energyOutput = double.Parse(args[3]);

		//Type clazz = Assembly.GetExecutingAssembly().GetTypes().FirstOrDefault(t => t.Name == type + "Provider");
		//var ctors = clazz.GetConstructors(BindingFlags.Public | BindingFlags.Instance);
		//IProvider provider = (IProvider)ctors[0].Invoke(new object[] { id, energyOutput });

		IProvider provider = (IProvider)Activator.CreateInstance(providerType, id, energyOutput);
        return provider;
    }
}