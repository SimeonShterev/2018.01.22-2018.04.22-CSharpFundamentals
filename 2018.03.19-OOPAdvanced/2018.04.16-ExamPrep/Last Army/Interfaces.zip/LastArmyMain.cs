﻿using System;
using System.Text;

class LastArmyMain
{
	static void Main()
	{
		Engine engine = new Engine();
		engine.Run();
	}
}