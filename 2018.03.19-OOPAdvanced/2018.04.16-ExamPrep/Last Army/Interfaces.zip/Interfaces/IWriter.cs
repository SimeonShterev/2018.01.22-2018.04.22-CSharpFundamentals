﻿public interface IWriter
{
	void WriteLine(string output);

	void Append(string text);

	void PrintResult();
}