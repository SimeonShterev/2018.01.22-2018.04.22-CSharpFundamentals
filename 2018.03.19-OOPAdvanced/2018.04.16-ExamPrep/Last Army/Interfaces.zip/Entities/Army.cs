﻿using System.Collections.Generic;

public class Army
{
	private List<ISoldier> soldiers;


}