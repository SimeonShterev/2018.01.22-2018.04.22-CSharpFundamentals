﻿using System.Collections.Generic;

public class Warehouse : IWareHouse
{
	private List<IAmmunition> weapons;

	public void EquipArmy(IArmy army)
	{
		throw new System.NotImplementedException();
	}
}