﻿public class RPG : Ammunition
{
	public const double weight = 17.1;

	public override double Weight => weight;
}