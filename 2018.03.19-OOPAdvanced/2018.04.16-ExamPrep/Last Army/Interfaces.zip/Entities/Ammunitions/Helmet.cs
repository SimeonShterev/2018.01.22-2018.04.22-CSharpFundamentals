﻿public class Helmet : Ammunition
{
	public const double weight = 2.3;

	public override double Weight => weight;
}