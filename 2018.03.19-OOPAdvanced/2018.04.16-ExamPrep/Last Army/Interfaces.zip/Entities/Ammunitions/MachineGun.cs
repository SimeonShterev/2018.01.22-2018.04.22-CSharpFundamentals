﻿public class MachineGun : Ammunition
{
	public const double weight = 10.6;

	public override double Weight => weight;
}