﻿public class Knife : Ammunition
{
	public const double weight = 0.4;

	public override double Weight => weight;
}