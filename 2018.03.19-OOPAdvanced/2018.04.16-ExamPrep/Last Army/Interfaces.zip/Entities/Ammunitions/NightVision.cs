﻿public class NightVision : Ammunition
{
	public const double weight = 0.8;

	public override double Weight => weight;
}