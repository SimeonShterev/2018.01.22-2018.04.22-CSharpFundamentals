﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Travel.Constants
{
    public static class Consts
    {
		public const string PassangerAlreadyCheckedIn = "{0} is already checked in!";
	}
}
