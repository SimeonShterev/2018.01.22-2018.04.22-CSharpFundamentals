﻿namespace Travel.Entities.Items
{
	public class CellPhone : Item
	{
		public CellPhone()
			: base(value: 700)
		{
		}
	}
}